// import React from 'react'
// import UserProfile from './User/UserProfile'



// const HomePage = ({account}) => {
//   // lina home page mt3 user 3adi 
//   // ici on peut afficher notre user account et un petit button pour faire l'update de son profil 

//   return (
//     <div> 

// <UserProfile  account={account}/>

//        </div>
//   )
// }



// export default HomePage